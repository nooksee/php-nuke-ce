<?php
declare(strict_types=1);


/*
 * PHP-Nuke CE (Community Edition / Custom Edition)
 * Project name in-code: nukeCE
 */

namespace NukeCE\Modules\AdminNukesecurity;

use NukeCE\Core\ModuleInterface;
use NukeCE\Core\AdminLayout;
use NukeCE\Core\AppConfig;
use NukeCE\Security\Csrf;
use NukeCE\Security\NukeSecurity;
use NukeCE\Security\NukeSecurityConfig;

/**
 * NukeSecurity Admin (log-only mode).
 * - log viewer
 * - export CSV/JSON
 * - thresholds + webhook/email placeholders
 *
 * This is designed to be "php-nuke-y": simple, one-screen, practical.
 */
final class AdminNukesecurityModule implements ModuleInterface
{
    public function getName(): string
    {
        return 'admin_nukesecurity';
    }

    public function handle(array $params): void
    {
        NukeSecurity::log('admin_nukesecurity', 'view');

        $root = defined('NUKECE_ROOT') ? NUKECE_ROOT : dirname(__DIR__, 2);
        $logFile = $root . '/data/nukesecurity.log';
        $cfgFile = $root . '/data/nukesecurity.json'; // kept for UI display
        $cfg = NukeSecurityConfig::load($root);


                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            Csrf::requireValid($_POST['_csrf'] ?? '');
            $action = (string)($_POST['action'] ?? 'save');

            if ($action === 'save_messages_audit') {
                $cfg = NukeSecurityConfig::load($rootDir);
                $mode = (string)($_POST['audit_mode'] ?? 'private');
                if (!in_array($mode, ['private','audit','hybrid'], true)) $mode = 'private';
                if (!isset($cfg['messages']) || !is_array($cfg['messages'])) $cfg['messages'] = [];
                $cfg['messages']['audit_mode'] = $mode;
                NukeSecurityConfig::save($rootDir, $cfg);
                $msg = 'Messages audit mode saved.';
            } elseif ($action === 'save') {
                $cfg['alerts'] = [
                    'email' => trim((string)($_POST['alert_email'] ?? '')),
                    'webhook' => trim((string)($_POST['alert_webhook'] ?? '')),
                    'threshold' => max(1, (int)($_POST['alert_threshold'] ?? 10)),
                ];
                NukeSecurityConfig::save($root, $cfg);
                NukeSecurity::log('admin_nukesecurity', 'save_cfg', $cfg['alerts']);
            }
        }

        // Exports
        $export = (string)($_GET['export'] ?? '');
        if ($export === 'json') {
            $this->exportJson($logFile);
            return;
        }
        if ($export === 'csv') {
            $this->exportCsv($logFile);
            return;
        }

        $csrf = Csrf::token();
        $lines = is_file($logFile) ? (file($logFile, FILE_IGNORE_NEW_LINES) ?: []) : [];
        $recent = array_slice($lines, -200);

        AdminLayout::header('NukeSecurity');
        echo "<div class='wrap'><div class='card'>";
        echo "<div style='display:flex;justify-content:space-between;gap:12px;align-items:center'>";
        echo "<div><h1 class='h1'><?= AdminLayout::icon('security','nukesecurity') ?>NukeSecurity</h1><div class='muted'><small>Log-only mode. (Attribution preserved in CREDITS.)</small></div></div>";
        echo "<div><a class='btn2' href='/index.php?module=admin_nukesecurity&export=json'>Export JSON</a> ";
        echo "<a class='btn2' href='/index.php?module=admin_nukesecurity&export=csv'>Export CSV</a></div>";
        echo "</div>";

        // Dashboard widget
        $count = count($recent);
        echo "<div style='margin-top:12px' class='grid'>";
        echo "<div class='card' style='padding:12px'><b>Recent events</b><div class='muted'><small>Last 200 lines</small></div><div style='font-size:28px;margin-top:6px'>{$count}</div></div>";
        echo "<div class='card' style='padding:12px'><b>Alert threshold</b><div class='muted'><small>Trigger when events exceed threshold</small></div><div style='font-size:28px;margin-top:6px'>" . (int)($cfg['alerts']['threshold'] ?? 10) . "</div></div>";
        echo "<div class='card' style='padding:12px'><b>Status</b><div class='muted'><small>Enforcement</small></div><div style='font-size:28px;margin-top:6px'>LOG</div></div>";
        echo "</div>";

        echo "<h2 style='margin:14px 0 8px 0'>Log Viewer</h2>";
        echo "<div style='border:1px solid #e2e2e2;border-radius:14px;background:#0b0b0b;color:#eaeaea;padding:10px;max-height:420px;overflow:auto;font-family:ui-monospace,Menlo,monospace;font-size:12px'>";
        if (!$recent) echo "<div class='muted'><small>No log yet.</small></div>";
        foreach ($recent as $ln) {
            echo htmlspecialchars($ln, ENT_QUOTES, 'UTF-8') . "<br>";
        }
        echo "</div>";

        echo "<h2 style='margin:14px 0 8px 0'>Alerts</h2>";
        
// Compat status panel (legacy imports)
$compat = is_array($cfg['compat'] ?? null) ? $cfg['compat'] : [];
$migrated = !empty($compat['migrated']);
$migratedAt = (string)($compat['migrated_at'] ?? '');
$from = $compat['migrated_from'] ?? [];
if (!is_array($from)) $from = [];

$legacyImport = $compat['legacy_import'] ?? [];
if (!is_array($legacyImport)) $legacyImport = [];

$map = $compat['legacy_key_map'] ?? [];
if (!is_array($map)) $map = [];

echo "<div class='card' style='margin-top:12px;padding:12px'>";
echo "<div style='display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap'>";
echo "<div><b>Compat status</b><div class='muted'><small>Legacy NukeSentinel / nsnst imports into NukeSecurity</small></div></div>";
echo $migrated ? "<span class='badge ok'>migrated</span>" : "<span class='badge'>no legacy detected</span>";
echo "</div>";

echo "<div style='margin-top:10px' class='grid'>";
echo "<div class='card' style='padding:10px'><b>Sources</b><div class='muted'><small>" . ($from ? htmlspecialchars(implode(', ', $from), ENT_QUOTES, 'UTF-8') : "None") . "</small></div>";
if ($migratedAt) echo "<div class='muted'><small>At: " . htmlspecialchars($migratedAt, ENT_QUOTES, 'UTF-8') . "</small></div>";
echo "</div>";

echo "<div class='card' style='padding:10px'><b>Mapped keys</b><div class='muted'><small>" . count($map) . " known mappings</small></div>";
echo "<div style='margin-top:6px;max-height:110px;overflow:auto;font-family:ui-monospace, SFMono-Regular, Menlo, monospace;font-size:12px;white-space:pre-wrap'>";
foreach ($map as $k => $v) {
    if (!is_string($k) || !is_string($v)) continue;
    echo htmlspecialchars($k . " -> " . $v, ENT_QUOTES, 'UTF-8') . "\n";
}
echo "</div></div>";

echo "<div class='card' style='padding:10px'><b>Imported legacy keys</b><div class='muted'><small>" . count($legacyImport) . " captured</small></div>";
echo "<div style='margin-top:6px;max-height:110px;overflow:auto;font-family:ui-monospace, SFMono-Regular, Menlo, monospace;font-size:12px;white-space:pre-wrap'>";
$shown = 0;
foreach ($legacyImport as $k => $v) {
    if (!is_string($k)) continue;
    $shown++;
    if ($shown > 50) { echo "... (truncated)\n"; break; }
    $val = is_scalar($v) ? (string)$v : json_encode($v);
    echo htmlspecialchars($k . " = " . $val, ENT_QUOTES, 'UTF-8') . "\n";
}
echo "</div></div>";
echo "</div>"; // grid

echo "<div class='muted' style='margin-top:10px'><small>Tip: run <code>php install/migrate_nukesecurity_compat.php</code> to force a one-shot migration write, then refresh this page.</small></div>";
echo "</div>";
echo "<form method='post' action='/index.php?module=admin_nukesecurity' class='grid' style='grid-template-columns:repeat(3,minmax(0,1fr));gap:12px'>";
        echo "<input type='hidden' name='_csrf' value='{$csrf}'><input type='hidden' name='action' value='save'>";
        echo "<div><label>Email</label><input style='width:100%' name='alert_email' value='" . htmlspecialchars((string)($cfg['alerts']['email'] ?? ''), ENT_QUOTES,'UTF-8') . "' placeholder='you@example.com'></div>";
        echo "<div><label>Webhook</label><input style='width:100%' name='alert_webhook' value='" . htmlspecialchars((string)($cfg['alerts']['webhook'] ?? ''), ENT_QUOTES,'UTF-8') . "' placeholder='https://...'></div>";
        echo "<div><label>Threshold</label><input style='width:100%' type='number' min='1' name='alert_threshold' value='" . (int)($cfg['alerts']['threshold'] ?? 10) . "'></div>";
        echo "<div style='grid-column:1/-1'><button class='btn' type='submit'>Save</button></div>";
        echo "</form>";

        echo "</div></div>";
        
// Messages audit mode (Option C)
$cfg = NukeSecurityConfig::load($rootDir);
$mode = (string)($cfg['messages']['audit_mode'] ?? 'private');
$mPrivate = $mode === 'private' ? "selected" : "";
$mAudit = $mode === 'audit' ? "selected" : "";
$mHybrid = $mode === 'hybrid' ? "selected" : "";

echo "<hr style='margin:18px 0;border:none;border-top:1px solid #e6e6e6'>";
echo "<div class='card' style='padding:14px;display:grid;gap:10px'>";
echo "<b>Messages Audit</b>";
echo "<div class='muted'>Default is private. Audit/hybrid requires a reason and is logged.</div>";
echo "<form method='post' action='/index.php?module=admin_nukesecurity' style='display:flex;gap:10px;align-items:center;flex-wrap:wrap'>";
echo "<input type='hidden' name='_csrf' value='{$csrf}'>";
echo "<input type='hidden' name='action' value='save_messages_audit'>";
echo "<label>Mode <select name='audit_mode'>";
echo "<option value='private' {$mPrivate}>private</option>";
echo "<option value='hybrid' {$mHybrid}>hybrid</option>";
echo "<option value='audit' {$mAudit}>audit</option>";
echo "</select></label>";
echo "<button class='btn' type='submit'>Save</button>";
echo "</form>";
echo "</div>";

        
        // --- Paths & permissions (v17) ---
        $uploadsDir = AppConfig::getString('uploads_dir', $rootDir . '/uploads');
        $cacheDir   = AppConfig::getString('cache_dir',   $rootDir . '/cache');
        $tmpDir     = AppConfig::getString('tmp_dir',     $rootDir . '/tmp');
        $logsDir    = AppConfig::getString('logs_dir',    $rootDir . '/logs');

        $paths = [
            'uploads_dir' => $uploadsDir,
            'cache_dir'   => $cacheDir,
            'tmp_dir'     => $tmpDir,
            'logs_dir'    => $logsDir,
            'data_dir'    => AppConfig::getString('data_dir', $rootDir . '/data'),
        ];

        echo "<h2>Paths & permissions</h2>";
        echo "<p>Quick health check for filesystem paths used by nukeCE. These should exist and be writable where appropriate. In Apache deployments, .htaccess hardening is expected to deny direct HTTP access to sensitive folders.</p>";
        echo "<table class='nukece-table' style='width:100%'>";
        echo "<tr><th>Key</th><th>Path</th><th>Exists</th><th>Writable</th></tr>";
        foreach ($paths as $k => $p) {
            $ex = is_dir($p);
            $wr = $ex ? is_writable($p) : false;
            echo "<tr>";
            echo "<td>" . htmlspecialchars($k) . "</td>";
            echo "<td><code>" . htmlspecialchars($p) . "</code></td>";
            echo "<td>" . ($ex ? "YES" : "NO") . "</td>";
            echo "<td>" . ($wr ? "YES" : "NO") . "</td>";
            echo "</tr>";
        }
        echo "</table>";

        $allowInstall = $rootDir . "/config/ALLOW_INSTALL";
        echo "<h3>Installer lock</h3>";
        echo "<p>Installer is locked unless <code>config/ALLOW_INSTALL</code> exists.</p>";
        echo "<p>ALLOW_INSTALL: <b>" . (is_file($allowInstall) ? "PRESENT" : "ABSENT") . "</b></p>";


        AdminLayout::footer();
    }

    private function exportJson(string $logFile): void
    {
        header('Content-Type: application/json; charset=utf-8');
        $lines = is_file($logFile) ? (file($logFile, FILE_IGNORE_NEW_LINES) ?: []) : [];
        echo json_encode(['lines' => $lines], JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
    }

    private function exportCsv(string $logFile): void
    {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="nukesecurity.csv"');
        $lines = is_file($logFile) ? (file($logFile, FILE_IGNORE_NEW_LINES) ?: []) : [];
        $out = fopen('php://output', 'w');
        fputcsv($out, ['line']);
        foreach ($lines as $ln) fputcsv($out, [$ln]);
        fclose($out);
    }
}
