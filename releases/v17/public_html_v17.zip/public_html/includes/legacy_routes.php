<?php
declare(strict_types=1);
/**
 * Legacy route compatibility map.
 * Keep this lightweight and explicit; remove entries only via release train decision.
 */
return [
    'Links' => 'links',
'encyclopedia' => 'reference',
];
