<?php
declare(strict_types=1);

/*
 * PHP-Nuke CE (Community Edition / Custom Edition)
 * Project name in-code: nukeCE
 */

namespace NukeCE\Security;

use PDO;
use PDOException;

final class GeoIp
{
    private static ?PDO $pdo = null;

    private static function pdo(): PDO
    {
        if (self::$pdo !== null) return self::$pdo;

        $config = include __DIR__ . '/../../config/config.php';
        $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', $config['db_host'], $config['db_name']);
        self::$pdo = new PDO($dsn, $config['db_user'], $config['db_pass']);
        self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return self::$pdo;
    }

    /**
     * Resolve ISO2 country code for an IPv4 address.
     * Returns '' if not found or unsupported.
     */
    public static function countryForIp(string $ip): string
    {
        if ($ip === '' || $ip === 'cli') return '';
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false) return '';

        // Private/local ranges: treat as unknown (don't block)
        if (self::isPrivateIpv4($ip)) return '';

        $int = self::ipv4ToUInt($ip);
        if ($int === null) return '';

        try {
            $pdo = self::pdo();
            $st = $pdo->prepare("SELECT iso2 FROM nsec_geoip_ipv4 WHERE ? BETWEEN start_int AND end_int ORDER BY (end_int-start_int) ASC LIMIT 1");
            $st->execute([$int]);
            $iso = (string)($st->fetchColumn() ?: '');
            return strtoupper(substr($iso, 0, 2));
        } catch (PDOException $e) {
            // Schema not installed or DB unavailable; fail open.
            return '';
        }
    }

    private static function ipv4ToUInt(string $ip): ?int
    {
        $long = ip2long($ip);
        if ($long === false) return null;
        // convert signed to unsigned
        if ($long < 0) $long = $long + 4294967296;
        return (int)$long;
    }

    private static function isPrivateIpv4(string $ip): bool
    {
        $long = ip2long($ip);
        if ($long === false) return true;
        if ($long < 0) $long += 4294967296;

        // 10.0.0.0/8
        if ($long >= 167772160 && $long <= 184549375) return true;
        // 172.16.0.0/12
        if ($long >= 2886729728 && $long <= 2887778303) return true;
        // 192.168.0.0/16
        if ($long >= 3232235520 && $long <= 3232301055) return true;
        // 127.0.0.0/8 localhost
        if ($long >= 2130706432 && $long <= 2147483647) return true;

        return false;
    }
}
