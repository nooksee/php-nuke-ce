# Keep non-public content out of public_html

This directory is intended to be served by your web server.

Do NOT place these here:
- transcripts
- canon decisions
- claim registry
- reference nodes
- boot packs
- raw documentation dumps

Keep those under `nukece_meta/`.
