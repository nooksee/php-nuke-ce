<?php
// Local development config
define('DB_HOST', 'localhost');
define('DB_NAME', 'nukece');
define('DB_USER', 'nukece');
define('DB_PASS', '8109');
