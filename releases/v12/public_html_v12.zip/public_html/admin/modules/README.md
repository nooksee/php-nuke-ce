# admin/modules (legacy)

nukeCE uses **modules/admin_*** for admin subsystems and routes through `admin.php`.

This directory is intentionally kept empty to avoid drift.
