<?php
declare(strict_types=1);


/*
 * PHP-Nuke CE (Community Edition / Custom Edition)
 * Project name in-code: nukeCE
 */

namespace NukeCE\Security;


use NukeCE\Core\AppConfig;
/**
 * nukeCE security event logger (log-only mode).
 *
 * This is the modernized successor to the classic NukeSentinel concept.
 * - We keep attribution in CREDITS and docs.
 * - We do NOT reuse old identifier prefixes in our own schema (use nsec_).
 */
final class NukeSecurity
{
    public static function log(string $area, string $event, array $meta = []): void
    {
        $root = defined('NUKECE_ROOT') ? NUKECE_ROOT : dirname(__DIR__, 2);
        $file = $root . '/data/nukesecurity.log';
        @mkdir(dirname($file), 0755, true);

        $ip = $_SERVER['REMOTE_ADDR'] ?? 'cli';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $line = sprintf(
            "[%s] area=%s event=%s ip=%s ua=%s meta=%s",
            gmdate('c'),
            self::clean($area),
            self::clean($event),
            self::clean($ip),
            self::clean(substr($ua, 0, 80)),
            $meta ? json_encode($meta, JSON_UNESCAPED_SLASHES) : "{}"
        );

        @file_put_contents($file, $line . PHP_EOL, FILE_APPEND | LOCK_EX);
    }

    private static function clean(string $s): string
    {
        return preg_replace('/[^a-z0-9_\-\.]/i', '_', $s) ?? $s;
    }
}
