<?php
/**
 * PHP-Nuke CE
 * Block: Club Hub
 */
if (!defined('NUKECE_ROOT')) { return; }
$content = '<div class="block"><strong>Club Hub</strong><div><a href="/index.php?module=clubs">Browse clubs</a></div></div>';
