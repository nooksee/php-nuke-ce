<?php
declare(strict_types=1);
// Copy to ENABLED_OPTIONAL_MODULES.php and list optional modules you want enabled.
return [
  // 'faq',
  // 'weblinks',
];
