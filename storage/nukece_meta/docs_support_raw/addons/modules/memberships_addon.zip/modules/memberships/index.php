<?php
/**
 * PHP-Nuke CE
 * Memberships (optional add-on)
 */
require_once __DIR__ . '/../../mainfile.php';

use NukeCE\Core\Layout;
use NukeCE\Core\Model;

Layout::header('Members');

$pdo = Model::pdo();
$pdo->exec("CREATE TABLE IF NOT EXISTS memberships_tiers (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(80) NOT NULL,
  slug VARCHAR(80) NOT NULL,
  description MEDIUMTEXT NULL,
  is_public TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 10,
  PRIMARY KEY (id),
  UNIQUE KEY uq_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$pdo->exec("CREATE TABLE IF NOT EXISTS memberships_user (
  username VARCHAR(64) NOT NULL,
  tier_slug VARCHAR(80) NOT NULL,
  granted_at DATETIME NOT NULL,
  granted_by VARCHAR(64) NOT NULL DEFAULT 'admin',
  expires_at DATETIME NULL,
  PRIMARY KEY (username, tier_slug),
  KEY idx_tier (tier_slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$tiers = $pdo->query("SELECT name,slug,description FROM memberships_tiers WHERE is_public=1 ORDER BY sort_order ASC, id ASC")
  ->fetchAll(PDO::FETCH_ASSOC) ?: [];

echo '<h1>Members</h1>';
echo '<p>Support tiers and benefits. (Optional add-on)</p>';

if (!$tiers) {
  echo '<p>No public tiers yet.</p>';
} else {
  echo '<div class="nukece-cards">';
  foreach ($tiers as $t) {
    echo '<div class="nukece-card">';
    echo '<h3>'.htmlspecialchars((string)$t['name'], ENT_QUOTES, 'UTF-8').'</h3>';
    echo '<div>'.nl2br(htmlspecialchars((string)($t['description'] ?? ''), ENT_QUOTES, 'UTF-8')).'</div>';
    echo '</div>';
  }
  echo '</div>';
}

Layout::footer();
