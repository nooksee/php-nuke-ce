<?php
declare(strict_types=1);

namespace NukeCE\Modules\Memberships;

use NukeCE\Core\Model;

final class Gate
{
    public static function userHasTier(string $username, string $tierSlug): bool
    {
        $pdo = Model::pdo();
        $st = $pdo->prepare("SELECT 1 FROM memberships_user WHERE username=? AND tier_slug=? LIMIT 1");
        $st->execute([$username, $tierSlug]);
        return (bool)$st->fetchColumn();
    }
}
