<?php
/**
 * PHP-Nuke CE
 * Admin Memberships (optional add-on)
 */
require_once __DIR__ . '/../../mainfile.php';
require_once NUKECE_ROOT . '/includes/admin_ui.php';

use NukeCE\Core\Model;

AdminUi::requireAdmin();
include_once NUKECE_ROOT . '/includes/header.php';

$pdo = Model::pdo();
$pdo->exec("CREATE TABLE IF NOT EXISTS memberships_tiers (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(80) NOT NULL,
  slug VARCHAR(80) NOT NULL,
  description MEDIUMTEXT NULL,
  is_public TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 10,
  PRIMARY KEY (id),
  UNIQUE KEY uq_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$pdo->exec("CREATE TABLE IF NOT EXISTS memberships_user (
  username VARCHAR(64) NOT NULL,
  tier_slug VARCHAR(80) NOT NULL,
  granted_at DATETIME NOT NULL,
  granted_by VARCHAR(64) NOT NULL DEFAULT 'admin',
  expires_at DATETIME NULL,
  PRIMARY KEY (username, tier_slug),
  KEY idx_tier (tier_slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$csrf = class_exists('NukeCE\\Security\\Csrf') ? \NukeCE\Security\Csrf::token() : '';
$msg = '';

function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (class_exists('NukeCE\\Security\\Csrf') && !\NukeCE\Security\Csrf::validate($_POST['_csrf'] ?? null)) {
    $msg = 'Invalid CSRF token.';
  } else {
    $action = (string)($_POST['action'] ?? '');
    if ($action === 'add_tier') {
      $name = trim((string)($_POST['name'] ?? ''));
      $slug = trim((string)($_POST['slug'] ?? ''));
      $desc = trim((string)($_POST['description'] ?? ''));
      $pub = !empty($_POST['is_public']) ? 1 : 0;
      $sort = (int)($_POST['sort_order'] ?? 10);
      if ($name !== '' && $slug !== '') {
        $st = $pdo->prepare("INSERT INTO memberships_tiers (name,slug,description,is_public,sort_order) VALUES (?,?,?,?,?)");
        $st->execute([$name,$slug,$desc,$pub,$sort]);
        $msg = 'Tier added.';
      }
    } elseif ($action === 'grant') {
      $user = trim((string)($_POST['username'] ?? ''));
      $tier = trim((string)($_POST['tier_slug'] ?? ''));
      if ($user !== '' && $tier !== '') {
        $st = $pdo->prepare("INSERT INTO memberships_user (username,tier_slug,granted_at,granted_by) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE granted_at=VALUES(granted_at), granted_by=VALUES(granted_by)");
        $st->execute([$user,$tier,gmdate('Y-m-d H:i:s'),'admin']);
        $msg = 'Granted.';
      }
    }
  }
}

AdminUi::header('Members', [
  '/admin' => 'Dashboard',
  '/admin.php?op=logout' => 'Logout',
]);

if ($msg) { AdminUi::groupStart('Message'); echo '<p>'.h($msg).'</p>'; AdminUi::groupEnd(); }

AdminUi::groupStart('Tiers', 'Create support tiers (manual or future payments).');
echo '<form method="post">';
if ($csrf) echo '<input type="hidden" name="_csrf" value="'.h($csrf).'">';
echo '<input type="hidden" name="action" value="add_tier">';
echo '<p><label>Name<br><input name="name"></label></p>';
echo '<p><label>Slug (e.g. supporter)<br><input name="slug"></label></p>';
echo '<p><label>Description<br><textarea name="description" rows="4" style="width:100%"></textarea></label></p>';
echo '<p><label><input type="checkbox" name="is_public" value="1" checked> Public</label></p>';
echo '<p><label>Sort order<br><input name="sort_order" value="10"></label></p>';
echo '<p><button class="nukece-btn nukece-btn-primary" type="submit">Add Tier</button></p>';
echo '</form>';

$tiers = $pdo->query("SELECT name,slug,is_public FROM memberships_tiers ORDER BY sort_order ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
if ($tiers) {
  echo '<table><tr><th>Name</th><th>Slug</th><th>Public</th></tr>';
  foreach ($tiers as $t) {
    echo '<tr><td>'.h((string)$t['name']).'</td><td>'.h((string)$t['slug']).'</td><td>'.(((int)$t['is_public']===1)?'yes':'no').'</td></tr>';
  }
  echo '</table>';
}
AdminUi::groupEnd();

AdminUi::groupStart('Grant', 'Manually grant a tier to a user.');
echo '<form method="post">';
if ($csrf) echo '<input type="hidden" name="_csrf" value="'.h($csrf).'">';
echo '<input type="hidden" name="action" value="grant">';
echo '<p><label>Username<br><input name="username"></label></p>';
echo '<p><label>Tier slug<br><input name="tier_slug"></label></p>';
echo '<p><button class="nukece-btn nukece-btn-primary" type="submit">Grant</button></p>';
echo '</form>';
AdminUi::groupEnd();

AdminUi::footer();
include_once NUKECE_ROOT . '/includes/footer.php';
