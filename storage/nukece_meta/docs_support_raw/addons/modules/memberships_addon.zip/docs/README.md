# Memberships add-on

Modern "support tiers" and entitlements (Patreon/YouTube style), without forcing commerce.

Admin: `/admin.php?op=memberships`
Public: `/index.php?module=memberships`
