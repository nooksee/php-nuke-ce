# Arcade add-on (optional)

Includes:
- Arcade module with leaderboards
- 3 starter HTML5 games (embedded)
- Add more games by dropping HTML files into `/games`

Admin: `/admin.php?op=arcade`
Public: `/index.php?module=arcade`

Starter games are tiny original demos for nukeCE (no third-party licensing risk).
