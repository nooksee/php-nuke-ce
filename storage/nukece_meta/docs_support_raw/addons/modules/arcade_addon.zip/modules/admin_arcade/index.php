<?php
/**
 * PHP-Nuke CE
 * Admin Arcade (optional add-on)
 */
require_once __DIR__ . '/../../mainfile.php';
require_once NUKECE_ROOT . '/includes/admin_ui.php';

use NukeCE\Core\Model;

AdminUi::requireAdmin();
include_once NUKECE_ROOT . '/includes/header.php';

$pdo = Model::pdo();
$pdo->exec("CREATE TABLE IF NOT EXISTS arcade_scores (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  created_at DATETIME NOT NULL,
  game_slug VARCHAR(64) NOT NULL,
  username VARCHAR(64) NOT NULL,
  score INT NOT NULL,
  PRIMARY KEY (id),
  KEY idx_game (game_slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$rows = $pdo->query("SELECT game_slug, COUNT(*) as plays FROM arcade_scores GROUP BY game_slug ORDER BY plays DESC")
  ->fetchAll(PDO::FETCH_ASSOC) ?: [];

AdminUi::header('Arcade', [
  '/admin' => 'Dashboard',
  '/admin.php?op=logout' => 'Logout',
]);

AdminUi::groupStart('Summary', 'Arcade is an optional add-on.');
if (!$rows) echo '<p>No plays yet.</p>';
else {
  echo '<table><tr><th>Game</th><th>Plays</th></tr>';
  foreach ($rows as $r) echo '<tr><td>'.htmlspecialchars((string)$r['game_slug']).'</td><td>'.(int)$r['plays'].'</td></tr>';
  echo '</table>';
}
AdminUi::groupEnd();

AdminUi::footer();
include_once NUKECE_ROOT . '/includes/footer.php';
