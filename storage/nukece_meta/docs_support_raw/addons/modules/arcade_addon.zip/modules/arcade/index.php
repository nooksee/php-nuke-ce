<?php
/**
 * PHP-Nuke CE
 * Arcade (optional add-on)
 */
require_once __DIR__ . '/../../mainfile.php';

use NukeCE\Core\Layout;
use NukeCE\Core\Model;

Layout::header('Arcade');

$pdo = Model::pdo();
$pdo->exec("CREATE TABLE IF NOT EXISTS arcade_scores (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  created_at DATETIME NOT NULL,
  game_slug VARCHAR(64) NOT NULL,
  username VARCHAR(64) NOT NULL,
  score INT NOT NULL,
  PRIMARY KEY (id),
  KEY idx_game (game_slug),
  KEY idx_user (username),
  KEY idx_score (score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$op = (string)($_GET['op'] ?? 'index');
$game = (string)($_GET['game'] ?? '');

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

echo '<h1>Arcade</h1>';
echo '<p>Starter games included. Scores post to the leaderboard.</p>';

$games = [
  'clicker' => 'Clicker',
  'memory'  => 'Memory',
  'runner'  => 'Runner',
];

if ($op === 'play' && isset($games[$game])) {
  echo '<p><a href="/index.php?module=arcade">← Back</a></p>';
  echo '<h3>'.h($games[$game]).'</h3>';
  echo '<iframe id="gameframe" src="/games/'.h($game).'.html" style="width:100%;height:420px;border:1px solid #999;border-radius:10px;"></iframe>';
  echo '<script>
  window.addEventListener("message", async (ev) => {
    if(!ev.data || typeof ev.data.arcadeScore==="undefined") return;
    const fd = new FormData();
    fd.append("game", ev.data.game || "'.h($game).'");
    fd.append("score", ev.data.arcadeScore);
    const res = await fetch("/index.php?module=arcade&op=submit", {method:"POST", body:fd});
    try { const j = await res.json(); alert("Score submitted: "+j.score); } catch(e) {}
  });
  </script>';
} elseif ($op === 'submit' && $_SERVER['REQUEST_METHOD']==='POST') {
  header('Content-Type: application/json; charset=utf-8');
  $g = preg_replace('/[^a-z0-9_-]/i','', (string)($_POST['game'] ?? ''));
  $s = (int)($_POST['score'] ?? 0);
  $user = class_exists('AuthGate') ? (AuthGate::currentUsername() ?: 'guest') : 'guest';
  if (!isset($games[$g]) || $s <= 0) { echo json_encode(['ok'=>false]); exit; }
  $st = $pdo->prepare("INSERT INTO arcade_scores (created_at, game_slug, username, score) VALUES (?,?,?,?)");
  $st->execute([gmdate('Y-m-d H:i:s'), $g, $user, $s]);
  echo json_encode(['ok'=>true, 'game'=>$g, 'score'=>$s, 'user'=>$user], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  exit;
} else {
  echo '<div class="nukece-cards">';
  foreach ($games as $slug=>$name) {
    echo '<div class="nukece-card"><h3>'.h($name).'</h3>';
    echo '<p><a href="/index.php?module=arcade&op=play&game='.h($slug).'">Play</a></p></div>';
  }
  echo '</div>';

  echo '<h2>Leaderboards</h2>';
  foreach ($games as $slug=>$name) {
    echo '<h3>'.h($name).'</h3>';
    $st = $pdo->prepare("SELECT username, MAX(score) as best FROM arcade_scores WHERE game_slug=? GROUP BY username ORDER BY best DESC LIMIT 10");
    $st->execute([$slug]);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    if (!$rows) { echo '<p>No scores yet.</p>'; continue; }
    echo '<table><tr><th>User</th><th>Best</th></tr>';
    foreach ($rows as $r) {
      echo '<tr><td>'.h($r['username']).'</td><td>'.(int)$r['best'].'</td></tr>';
    }
    echo '</table>';
  }
}

Layout::footer();
